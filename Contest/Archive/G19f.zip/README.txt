Shah Jainam EE21B122
Satwik Anand EE21B120
Shivam Shah EE21B124

Team JSS